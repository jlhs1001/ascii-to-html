# ascii_to_html

(Note: package is still in its early stages)

Made by Liam Seewald

Call the function:
```python
ascii_to_html("\x1b[4munderlined")
```

Enjoy!
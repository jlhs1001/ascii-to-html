# ascii_to_html

Made by Liam Seewald

First you import the package

Call the function:
```python
ascii_to_html("\x1b[4munderlined")
```

Enjoy!